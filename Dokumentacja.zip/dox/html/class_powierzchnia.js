var class_powierzchnia =
[
    [ "get_Punkty_lokalne", "class_powierzchnia.html#a4c96123962331c81e4173184992df91b", null ],
    [ "_Punkty_globalne", "class_powierzchnia.html#aaeefef401b5fe4eab2e5be31466e1be7", null ],
    [ "_Punkty_lokalne", "class_powierzchnia.html#a7bebb0367df91a5aaa9941afce0a022f", null ]
];