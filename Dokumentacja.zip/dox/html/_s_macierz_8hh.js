var _s_macierz_8hh =
[
    [ "SMacierz", "class_s_macierz.html", "class_s_macierz" ],
    [ "operator<<", "_s_macierz_8hh.html#a2fdaccc89a761197e0d2c50878629052", null ],
    [ "operator>>", "_s_macierz_8hh.html#aa44e50eebd8e42223132f7439ffe5006", null ]
];