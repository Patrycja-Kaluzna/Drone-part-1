var prostopadloscian_8cpp =
[
    [ "operator<<", "prostopadloscian_8cpp.html#a080d4d11ca30c69c45064ce48cfbed9b", null ]
];