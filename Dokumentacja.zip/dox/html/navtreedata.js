var NAVTREE =
[
  [ "Zadanie 5.1", "index.html", [
    [ "Przestrzenie nazw", null, [
      [ "Lista przestrzeni nazw", "namespaces.html", "namespaces" ],
      [ "Składowe przestrzeni nazw", "namespacemembers.html", [
        [ "Wszystko", "namespacemembers.html", null ],
        [ "Funkcje", "namespacemembers_func.html", null ],
        [ "Wyliczenia", "namespacemembers_enum.html", null ],
        [ "Wartości wyliczeń", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Klasy", "annotated.html", [
      [ "Lista klas", "annotated.html", "annotated_dup" ],
      [ "Indeks klas", "classes.html", null ],
      [ "Hierarchia klas", "hierarchy.html", "hierarchy" ],
      [ "Składowe klas", "functions.html", [
        [ "Wszystko", "functions.html", null ],
        [ "Funkcje", "functions_func.html", null ],
        [ "Zmienne", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Pliki", null, [
      [ "Lista plików", "files.html", "files" ],
      [ "Składowe plików", "globals.html", [
        [ "Wszystko", "globals.html", null ],
        [ "Funkcje", "globals_func.html", null ],
        [ "Definicje typów", "globals_type.html", null ],
        [ "Definicje", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_s_macierz_8hh.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';