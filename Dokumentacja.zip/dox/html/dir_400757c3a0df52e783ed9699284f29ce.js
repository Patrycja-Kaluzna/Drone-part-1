var dir_400757c3a0df52e783ed9699284f29ce =
[
    [ "lacze_do_gnuplota.cpp", "lacze__do__gnuplota_8cpp.html", "lacze__do__gnuplota_8cpp" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "powierzchnia.cpp", "powierzchnia_8cpp.html", "powierzchnia_8cpp" ],
    [ "prostopadloscian.cpp", "prostopadloscian_8cpp.html", "prostopadloscian_8cpp" ],
    [ "scena.cpp", "scena_8cpp.html", null ]
];