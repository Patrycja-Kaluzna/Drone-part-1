var powierzchnia_8hh =
[
    [ "Powierzchnia", "class_powierzchnia.html", "class_powierzchnia" ],
    [ "Wektor3D", "powierzchnia_8hh.html#adace056b5d6fc0590c0815433f95fc11", null ],
    [ "operator>>", "powierzchnia_8hh.html#a0bf9a8b9b974a27dda6bd680bb173f76", null ]
];