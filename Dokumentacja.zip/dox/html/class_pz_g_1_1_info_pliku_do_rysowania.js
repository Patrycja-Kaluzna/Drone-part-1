var class_pz_g_1_1_info_pliku_do_rysowania =
[
    [ "InfoPlikuDoRysowania", "class_pz_g_1_1_info_pliku_do_rysowania.html#a48bc8ad94ef5fd5120b668a566c9172e", null ],
    [ "WezNazwePliku", "class_pz_g_1_1_info_pliku_do_rysowania.html#ac92a5dc258f9b6164631e2ea5247a7a7", null ],
    [ "WezRodzRys", "class_pz_g_1_1_info_pliku_do_rysowania.html#a6a46f3c7b7a08dfa9d694f387f873234", null ],
    [ "WezSzerokosc", "class_pz_g_1_1_info_pliku_do_rysowania.html#a627bb615c50f3b03374774e6b974488b", null ],
    [ "ZmienNazwePliku", "class_pz_g_1_1_info_pliku_do_rysowania.html#ae734c69f5cecf9c0584e3a7f433340ea", null ],
    [ "_NazwaPliku", "class_pz_g_1_1_info_pliku_do_rysowania.html#a07ab06c56b9c3179e566a4123ab2a037", null ],
    [ "_RodzRys", "class_pz_g_1_1_info_pliku_do_rysowania.html#ac2512f2073c66164beb2e88db31344a4", null ],
    [ "_Szerokosc", "class_pz_g_1_1_info_pliku_do_rysowania.html#a56a03dde7a7a414dbf3c230812a8d741", null ]
];