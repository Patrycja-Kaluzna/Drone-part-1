var annotated_dup =
[
    [ "PzG", "namespace_pz_g.html", "namespace_pz_g" ],
    [ "Dron", "class_dron.html", "class_dron" ],
    [ "Powierzchnia", "class_powierzchnia.html", "class_powierzchnia" ],
    [ "Powierzchnia_dna", "class_powierzchnia__dna.html", null ],
    [ "Powierzchnia_wody", "class_powierzchnia__wody.html", null ],
    [ "Prostopadloscian", "class_prostopadloscian.html", "class_prostopadloscian" ],
    [ "Scena", "class_scena.html", "class_scena" ],
    [ "SMacierz", "class_s_macierz.html", "class_s_macierz" ],
    [ "SWektor", "class_s_wektor.html", "class_s_wektor" ]
];