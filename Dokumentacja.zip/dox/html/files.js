var files =
[
    [ "dron.hh", "dron_8hh.html", [
      [ "Dron", "class_dron.html", "class_dron" ]
    ] ],
    [ "lacze_do_gnuplota.cpp", "lacze__do__gnuplota_8cpp.html", "lacze__do__gnuplota_8cpp" ],
    [ "lacze_do_gnuplota.hh", "lacze__do__gnuplota_8hh.html", "lacze__do__gnuplota_8hh" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "powierzchnia.cpp", "powierzchnia_8cpp.html", "powierzchnia_8cpp" ],
    [ "powierzchnia.hh", "powierzchnia_8hh.html", "powierzchnia_8hh" ],
    [ "powierzchnia_dna.hh", "powierzchnia__dna_8hh.html", [
      [ "Powierzchnia_dna", "class_powierzchnia__dna.html", null ]
    ] ],
    [ "powierzchnia_wody.hh", "powierzchnia__wody_8hh.html", [
      [ "Powierzchnia_wody", "class_powierzchnia__wody.html", null ]
    ] ],
    [ "prostopadloscian.cpp", "prostopadloscian_8cpp.html", "prostopadloscian_8cpp" ],
    [ "prostopadloscian.hh", "prostopadloscian_8hh.html", "prostopadloscian_8hh" ],
    [ "scena.cpp", "scena_8cpp.html", null ],
    [ "scena.hh", "scena_8hh.html", [
      [ "Scena", "class_scena.html", "class_scena" ]
    ] ],
    [ "SMacierz.hh", "_s_macierz_8hh.html", "_s_macierz_8hh" ],
    [ "SWektor.hh", "_s_wektor_8hh.html", "_s_wektor_8hh" ]
];