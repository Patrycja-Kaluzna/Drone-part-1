var prostopadloscian_8hh =
[
    [ "Prostopadloscian", "class_prostopadloscian.html", "class_prostopadloscian" ],
    [ "Macierz3x3", "prostopadloscian_8hh.html#aed1284f591ec1baca78f5efe8fb1b783", null ],
    [ "operator<<", "prostopadloscian_8hh.html#a080d4d11ca30c69c45064ce48cfbed9b", null ]
];