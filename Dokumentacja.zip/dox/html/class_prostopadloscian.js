var class_prostopadloscian =
[
    [ "Prostopadloscian", "class_prostopadloscian.html#a432b8df2af37ba1a3596f500824eaffe", null ],
    [ "get_Punkty_globalne", "class_prostopadloscian.html#a12ac2d8a7a37b0535b100cbadb5c659c", null ],
    [ "liczba_Punktow_globalnych", "class_prostopadloscian.html#ae499d0f86bacf0a5f51d0a76dc48ebf1", null ],
    [ "oblicz_Wektor_przemieszczenia", "class_prostopadloscian.html#aeabc287d369ba191309bff080305ae9c", null ],
    [ "ruch_na_wprost", "class_prostopadloscian.html#a3734bbb01df6aa5814dea5573a5ce9cf", null ],
    [ "ustaw_Kat_orientacji", "class_prostopadloscian.html#ae9b17db858fa1c2edba74b161e6a2337", null ],
    [ "ustaw_Macierz_rotacji_OZ", "class_prostopadloscian.html#a8af04bef5484fcc54afbe95a7d88eb14", null ],
    [ "wczytaj_globalne", "class_prostopadloscian.html#ac54e8c70a6fee0f731af07f3dc1ef564", null ],
    [ "zmiana_orientacji_OZ", "class_prostopadloscian.html#a921b963e224ef0a341ac9e37885f0b99", null ],
    [ "_Kat_orientacji", "class_prostopadloscian.html#ac7c176e021eff82282c5f1af1dc9e100", null ],
    [ "_Macierz_rotacji", "class_prostopadloscian.html#aab301112ed2431146a852221c58e2e2a", null ],
    [ "_Wektor_translacji", "class_prostopadloscian.html#ab5bef65c8a4708b2d238b50e2a1aa186", null ]
];