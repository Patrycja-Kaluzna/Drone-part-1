var lacze__do__gnuplota_8cpp =
[
    [ "ROZ_LINII", "lacze__do__gnuplota_8cpp.html#a2b501945c8d86114fcf6420cc1ee6306", null ],
    [ "STDIN", "lacze__do__gnuplota_8cpp.html#ac00bfb46347d26fdc58568fe1ab5fa5b", null ],
    [ "STDOUT", "lacze__do__gnuplota_8cpp.html#a8875037d0772a4fc34516f1e03d7e238", null ],
    [ "CzyJestPlik", "lacze__do__gnuplota_8cpp.html#ae1ae4d36f66c77879380ba73da8e20e3", null ]
];