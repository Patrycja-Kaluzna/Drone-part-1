var class_s_macierz =
[
    [ "elementy2", "class_s_macierz.html#a3cd9004838b3e17e11bb34395a689888", null ],
    [ "oblicz_wyznacznik", "class_s_macierz.html#adf2adc2457057f5fc800b00e3c558d3f", null ],
    [ "operator()", "class_s_macierz.html#ac28c02cc8f12e13446bd3c876dc3addf", null ],
    [ "operator()", "class_s_macierz.html#a1fe1fa358a098a484c69ba6fc9585403", null ],
    [ "operator*", "class_s_macierz.html#ac6173d6cc22102476c356ec43879123c", null ],
    [ "operator[]", "class_s_macierz.html#a4fb4c8623f1d9717f8e5973130f19f0c", null ],
    [ "operator[]", "class_s_macierz.html#a7b5ccba04f1fd2034e9356b8ab512958", null ],
    [ "podmien_kolumne", "class_s_macierz.html#a05654dc4325b5999bf194bf4cc1fd493", null ],
    [ "transponuj", "class_s_macierz.html#a1ad17cafd1110fe5a4149c1bb325958e", null ],
    [ "zamien_kolumny", "class_s_macierz.html#a8f0d3e5ec2755f8a8c364aa4fdb1b74a", null ],
    [ "kolumny", "class_s_macierz.html#ab99a2af7b476359f3b7aadb7897b277e", null ]
];