var class_scena =
[
    [ "Scena", "class_scena.html#a8f9fe11b4cfef890123a2acc94672e17", null ],
    [ "rysuj", "class_scena.html#aeb2b4cf0e2c0d69194859f74d3144d47", null ],
    [ "stworz", "class_scena.html#a477f06404e9ab92595af096aa886aeee", null ],
    [ "_Dron", "class_scena.html#a63cae72a349d4c5f3d39dc4b600b0768", null ],
    [ "_Pdna", "class_scena.html#add5493ee6bd7f52fcac37c83e14c6d96", null ],
    [ "_Pwody", "class_scena.html#a752d3203a1b46f68722987619353b3ee", null ]
];