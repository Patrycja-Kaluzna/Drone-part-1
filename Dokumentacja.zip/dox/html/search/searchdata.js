var indexSectionsWithContent =
{
  0: "_abcdegiklmoprstuwxyz~",
  1: "dilps",
  2: "p",
  3: "dlmps",
  4: "bcdegiklmoprstuwxyz~",
  5: "_aklw",
  6: "mw",
  7: "rt",
  8: "rt",
  9: "rs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne",
  6: "Definicje typów",
  7: "Wyliczenia",
  8: "Wartości wyliczeń",
  9: "Definicje"
};

