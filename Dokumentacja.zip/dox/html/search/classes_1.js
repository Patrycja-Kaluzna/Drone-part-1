var searchData=
[
  ['infoplikudorysowania',['InfoPlikuDoRysowania',['../class_pz_g_1_1_info_pliku_do_rysowania.html',1,'PzG']]]
];
