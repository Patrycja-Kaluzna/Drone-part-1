var searchData=
[
  ['elementy2',['elementy2',['../class_s_macierz.html#a3cd9004838b3e17e11bb34395a689888',1,'SMacierz']]]
];
