var searchData=
[
  ['xmax',['Xmax',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a8e23479629af3df3d352b7839ae396b8',1,'PzG::LaczeDoGNUPlota']]],
  ['xmin',['Xmin',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a66836c9749bf179420e4ca3e9447efd7',1,'PzG::LaczeDoGNUPlota']]]
];
