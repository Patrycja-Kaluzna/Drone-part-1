var searchData=
[
  ['transponuj',['transponuj',['../class_s_macierz.html#a1ad17cafd1110fe5a4149c1bb325958e',1,'SMacierz']]]
];
