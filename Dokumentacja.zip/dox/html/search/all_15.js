var searchData=
[
  ['_7elaczedognuplota',['~LaczeDoGNUPlota',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#afc10ec7f193032ecae714f6d832dcbf0',1,'PzG::LaczeDoGNUPlota']]],
  ['_7eswektor',['~SWektor',['../class_s_wektor.html#a828648454ff1f32ec81fca4d28c98574',1,'SWektor']]]
];
