var searchData=
[
  ['macierz3x3',['Macierz3x3',['../prostopadloscian_8hh.html#aed1284f591ec1baca78f5efe8fb1b783',1,'prostopadloscian.hh']]]
];
