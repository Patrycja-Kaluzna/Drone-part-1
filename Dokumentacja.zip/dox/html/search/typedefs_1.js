var searchData=
[
  ['wektor3d',['Wektor3D',['../powierzchnia_8hh.html#adace056b5d6fc0590c0815433f95fc11',1,'powierzchnia.hh']]]
];
