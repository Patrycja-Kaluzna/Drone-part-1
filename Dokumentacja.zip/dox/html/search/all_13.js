var searchData=
[
  ['ymax',['Ymax',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#ac54e4e7448ce3bd324efdc94a999f535',1,'PzG::LaczeDoGNUPlota']]],
  ['ymin',['Ymin',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a9352c0382bfaeaaba9f65399a7383164',1,'PzG::LaczeDoGNUPlota']]]
];
