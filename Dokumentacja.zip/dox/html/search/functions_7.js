var searchData=
[
  ['laczedognuplota',['LaczeDoGNUPlota',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a5845189b5ab8c3634acf57024e5deeaf',1,'PzG::LaczeDoGNUPlota']]],
  ['liczba_5fpunktow_5fglobalnych',['liczba_Punktow_globalnych',['../class_prostopadloscian.html#ae499d0f86bacf0a5f51d0a76dc48ebf1',1,'Prostopadloscian']]]
];
