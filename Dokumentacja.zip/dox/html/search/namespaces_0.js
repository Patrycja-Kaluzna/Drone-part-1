var searchData=
[
  ['pzg',['PzG',['../namespace_pz_g.html',1,'']]]
];
