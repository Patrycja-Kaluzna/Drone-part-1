var searchData=
[
  ['budujpreambule_5f2d',['BudujPreambule_2D',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a0ac655ff1934abb69ea668cd92ae77ec',1,'PzG::LaczeDoGNUPlota']]],
  ['budujpreambule_5f3d',['BudujPreambule_3D',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a50a544677e52829cac4dd4a95b821dcb',1,'PzG::LaczeDoGNUPlota']]],
  ['budujpreambulepoleceniarysowania',['BudujPreambulePoleceniaRysowania',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a0da98f68f533070d5a32adbdb519cf56',1,'PzG::LaczeDoGNUPlota']]]
];
