var searchData=
[
  ['kolumny',['kolumny',['../class_s_macierz.html#ab99a2af7b476359f3b7aadb7897b277e',1,'SMacierz']]]
];
