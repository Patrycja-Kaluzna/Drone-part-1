var searchData=
[
  ['czyjestplik',['CzyJestPlik',['../namespace_pz_g.html#ae1ae4d36f66c77879380ba73da8e20e3',1,'PzG']]],
  ['czypolaczeniejestzainicjowane',['CzyPolaczenieJestZainicjowane',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#af8be8aeb3b1b524fab67d4411cba5b9e',1,'PzG::LaczeDoGNUPlota']]],
  ['czywyswietlackomunikaty',['CzyWyswietlacKomunikaty',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a5e4f3a226ed36f7110032d802d84847c',1,'PzG::LaczeDoGNUPlota']]]
];
