var searchData=
[
  ['wspolrzedne',['wspolrzedne',['../class_s_wektor.html#acc26cb73843abbd778750cc5c108a2c4',1,'SWektor']]]
];
