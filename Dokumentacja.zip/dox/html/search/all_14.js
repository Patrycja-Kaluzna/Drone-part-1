var searchData=
[
  ['zamien_5fkolumny',['zamien_kolumny',['../class_s_macierz.html#a8f0d3e5ec2755f8a8c364aa4fdb1b74a',1,'SMacierz']]],
  ['zapiszustawienierotacjiiskali',['ZapiszUstawienieRotacjiISkali',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#aa92b463e8cbae31b50dd797a4183bce8',1,'PzG::LaczeDoGNUPlota']]],
  ['zapiszustawieniezakresu',['ZapiszUstawienieZakresu',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a4579aecf7b4777fdde0cae4e98c275c2',1,'PzG::LaczeDoGNUPlota']]],
  ['zmax',['Zmax',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a20a5d03e1fc19c682032bffc54340f12',1,'PzG::LaczeDoGNUPlota']]],
  ['zmiana_5forientacji_5foz',['zmiana_orientacji_OZ',['../class_prostopadloscian.html#a921b963e224ef0a341ac9e37885f0b99',1,'Prostopadloscian']]],
  ['zmiennazwepliku',['ZmienNazwePliku',['../class_pz_g_1_1_info_pliku_do_rysowania.html#ae734c69f5cecf9c0584e3a7f433340ea',1,'PzG::InfoPlikuDoRysowania']]],
  ['zmientrybrys',['ZmienTrybRys',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a10950349b348fd3a3d4143e95337527c',1,'PzG::LaczeDoGNUPlota']]],
  ['zmin',['Zmin',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a9068bd9a9873ba9c6d70016f1ae7cd7f',1,'PzG::LaczeDoGNUPlota']]]
];
