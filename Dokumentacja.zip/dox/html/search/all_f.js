var searchData=
[
  ['tr_5f2d',['TR_2D',['../namespace_pz_g.html#aeedae1ef10c66d720f9e89de408ca4caa5eb0cf8b3405e136f092efdb489d60c4',1,'PzG']]],
  ['tr_5f3d',['TR_3D',['../namespace_pz_g.html#aeedae1ef10c66d720f9e89de408ca4caa856e6b0fa6b8a9dc184c60cf27dcc5d2',1,'PzG']]],
  ['transponuj',['transponuj',['../class_s_macierz.html#a1ad17cafd1110fe5a4149c1bb325958e',1,'SMacierz']]],
  ['trybrysowania',['TrybRysowania',['../namespace_pz_g.html#aeedae1ef10c66d720f9e89de408ca4ca',1,'PzG']]]
];
