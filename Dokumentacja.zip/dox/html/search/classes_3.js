var searchData=
[
  ['powierzchnia',['Powierzchnia',['../class_powierzchnia.html',1,'']]],
  ['powierzchnia_5fdna',['Powierzchnia_dna',['../class_powierzchnia__dna.html',1,'']]],
  ['powierzchnia_5fwody',['Powierzchnia_wody',['../class_powierzchnia__wody.html',1,'']]],
  ['prostopadloscian',['Prostopadloscian',['../class_prostopadloscian.html',1,'']]]
];
