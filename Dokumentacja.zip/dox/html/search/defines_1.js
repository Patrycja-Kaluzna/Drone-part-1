var searchData=
[
  ['stdin',['STDIN',['../lacze__do__gnuplota_8cpp.html#ac00bfb46347d26fdc58568fe1ab5fa5b',1,'lacze_do_gnuplota.cpp']]],
  ['stdout',['STDOUT',['../lacze__do__gnuplota_8cpp.html#a8875037d0772a4fc34516f1e03d7e238',1,'lacze_do_gnuplota.cpp']]]
];
