var searchData=
[
  ['get_5faktualna_5filosc',['get_aktualna_ilosc',['../class_s_wektor.html#a349357c7b6e957b7a110735cca7840e7',1,'SWektor']]],
  ['get_5flaczna_5filosc',['get_laczna_ilosc',['../class_s_wektor.html#a36af83bef8d183e3ea23a1a0701ab7cf',1,'SWektor']]],
  ['get_5fpunkty_5fglobalne',['get_Punkty_globalne',['../class_prostopadloscian.html#a12ac2d8a7a37b0535b100cbadb5c659c',1,'Prostopadloscian']]],
  ['get_5fpunkty_5flokalne',['get_Punkty_lokalne',['../class_powierzchnia.html#a4c96123962331c81e4173184992df91b',1,'Powierzchnia']]]
];
