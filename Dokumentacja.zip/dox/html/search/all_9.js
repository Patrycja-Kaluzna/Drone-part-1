var searchData=
[
  ['lacze_5fdo_5fgnuplota_2ecpp',['lacze_do_gnuplota.cpp',['../lacze__do__gnuplota_8cpp.html',1,'']]],
  ['lacze_5fdo_5fgnuplota_2ehh',['lacze_do_gnuplota.hh',['../lacze__do__gnuplota_8hh.html',1,'']]],
  ['laczedognuplota',['LaczeDoGNUPlota',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html',1,'PzG::LaczeDoGNUPlota'],['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a5845189b5ab8c3634acf57024e5deeaf',1,'PzG::LaczeDoGNUPlota::LaczeDoGNUPlota()']]],
  ['laczna_5filosc',['laczna_ilosc',['../class_s_wektor.html#ac33103faf7c16ec1f4cc22752a4589db',1,'SWektor']]],
  ['liczba_5fpunktow_5fglobalnych',['liczba_Punktow_globalnych',['../class_prostopadloscian.html#ae499d0f86bacf0a5f51d0a76dc48ebf1',1,'Prostopadloscian']]]
];
