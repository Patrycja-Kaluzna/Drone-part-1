var searchData=
[
  ['dodajnazwepliku',['DodajNazwePliku',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a34bd48f57c0fd69c12bf4127a1cacd8f',1,'PzG::LaczeDoGNUPlota']]],
  ['dopiszplikidopoleceniarysowania',['DopiszPlikiDoPoleceniaRysowania',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#a25585ec3f1bd3b6bf42f374c38b8d237',1,'PzG::LaczeDoGNUPlota']]],
  ['dopiszrysowaniezplikow',['DopiszRysowanieZPlikow',['../class_pz_g_1_1_lacze_do_g_n_u_plota.html#ad3d7607946b82aa941d786dcd086d27e',1,'PzG::LaczeDoGNUPlota']]]
];
