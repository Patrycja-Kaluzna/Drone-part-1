var namespace_pz_g =
[
    [ "InfoPlikuDoRysowania", "class_pz_g_1_1_info_pliku_do_rysowania.html", "class_pz_g_1_1_info_pliku_do_rysowania" ],
    [ "LaczeDoGNUPlota", "class_pz_g_1_1_lacze_do_g_n_u_plota.html", "class_pz_g_1_1_lacze_do_g_n_u_plota" ]
];